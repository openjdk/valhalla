/*
 * Copyright (c) 2012, 2021, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 *
 */

#ifndef SHARE_OPTO_PHASETYPE_HPP
#define SHARE_OPTO_PHASETYPE_HPP

#define COMPILER_PHASES(flags) \
  flags(BEFORE_STRINGOPTS,            "Before StringOpts") \
  flags(AFTER_STRINGOPTS,             "After StringOpts") \
  flags(BEFORE_REMOVEUSELESS,         "Before RemoveUseless") \
  flags(AFTER_PARSING,                "After Parsing") \
  flags(ITER_GVN1,                    "Iter GVN 1") \
  flags(EXPAND_VUNBOX,                "Expand VectorUnbox") \
  flags(SCALARIZE_VBOX,               "Scalarize VectorBox") \
  flags(INLINE_VECTOR_REBOX,          "Inline Vector Rebox Calls") \
  flags(EXPAND_VBOX,                  "Expand VectorBox") \
  flags(ELIMINATE_VBOX_ALLOC,         "Eliminate VectorBoxAllocate") \
  flags(PHASEIDEAL_BEFORE_EA,         "PhaseIdealLoop before EA") \
  flags(ITER_GVN_AFTER_VECTOR,        "Iter GVN after vector box elimination") \
  flags(ITER_GVN_BEFORE_EA,           "Iter GVN before EA") \
  flags(ITER_GVN_AFTER_EA,            "Iter GVN after EA") \
  flags(ITER_GVN_AFTER_ELIMINATION,   "Iter GVN after eliminating allocations and locks") \
  flags(PHASEIDEALLOOP1,              "PhaseIdealLoop 1") \
  flags(PHASEIDEALLOOP2,              "PhaseIdealLoop 2") \
  flags(PHASEIDEALLOOP3,              "PhaseIdealLoop 3") \
  flags(CCP1,                         "PhaseCCP 1") \
  flags(ITER_GVN2,                    "Iter GVN 2") \
  flags(PHASEIDEALLOOP_ITERATIONS,    "PhaseIdealLoop iterations") \
  flags(OPTIMIZE_FINISHED,            "Optimize finished") \
  flags(GLOBAL_CODE_MOTION,           "Global code motion") \
  flags(FINAL_CODE,                   "Final Code") \
  flags(AFTER_EA,                     "After Escape Analysis") \
  flags(BEFORE_CLOOPS,                "Before CountedLoop") \
  flags(AFTER_CLOOPS,                 "After CountedLoop") \
  flags(BEFORE_BEAUTIFY_LOOPS,        "Before beautify loops") \
  flags(AFTER_BEAUTIFY_LOOPS,         "After beautify loops") \
  flags(BEFORE_MATCHING,              "Before matching") \
  flags(MATCHING,                     "After matching") \
  flags(INCREMENTAL_INLINE,           "Incremental Inline") \
  flags(INCREMENTAL_INLINE_STEP,      "Incremental Inline Step") \
  flags(INCREMENTAL_INLINE_CLEANUP,   "Incremental Inline Cleanup") \
  flags(INCREMENTAL_BOXING_INLINE,    "Incremental Boxing Inline") \
  flags(CALL_CATCH_CLEANUP,           "Call catch cleanup") \
  flags(MACRO_EXPANSION,              "Macro expand") \
  flags(BARRIER_EXPANSION,            "Barrier expand") \
  flags(END,                          "End") \
  flags(FAILURE,                      "Failure") \
  flags(DEBUG,                        "Debug")

#define table_entry(name, description) PHASE_##name,
enum CompilerPhaseType {
<<<<<<< HEAD
  PHASE_BEFORE_STRINGOPTS,
  PHASE_AFTER_STRINGOPTS,
  PHASE_BEFORE_REMOVEUSELESS,
  PHASE_AFTER_PARSING,
  PHASE_ITER_GVN1,
  PHASE_EXPAND_VUNBOX,
  PHASE_SCALARIZE_VBOX,
  PHASE_INLINE_VECTOR_REBOX,
  PHASE_EXPAND_VBOX,
  PHASE_ELIMINATE_VBOX_ALLOC,
  PHASE_PHASEIDEAL_BEFORE_EA,
  PHASE_ITER_GVN_AFTER_VECTOR,
  PHASE_ITER_GVN_BEFORE_EA,
  PHASE_ITER_GVN_AFTER_EA,
  PHASE_ITER_GVN_AFTER_ELIMINATION,
  PHASE_PHASEIDEALLOOP1,
  PHASE_PHASEIDEALLOOP2,
  PHASE_PHASEIDEALLOOP3,
  PHASE_CCP1,
  PHASE_ITER_GVN2,
  PHASE_PHASEIDEALLOOP_ITERATIONS,
  PHASE_OPTIMIZE_FINISHED,
  PHASE_GLOBAL_CODE_MOTION,
  PHASE_FINAL_CODE,
  PHASE_AFTER_EA,
  PHASE_BEFORE_CLOOPS,
  PHASE_AFTER_CLOOPS,
  PHASE_BEFORE_BEAUTIFY_LOOPS,
  PHASE_AFTER_BEAUTIFY_LOOPS,
  PHASE_BEFORE_MATCHING,
  PHASE_MATCHING,
  PHASE_INCREMENTAL_INLINE,
  PHASE_INCREMENTAL_INLINE_STEP,
  PHASE_INCREMENTAL_INLINE_CLEANUP,
  PHASE_INCREMENTAL_BOXING_INLINE,
  PHASE_CALL_CATCH_CLEANUP,
  PHASE_INSERT_BARRIER,
  PHASE_MACRO_EXPANSION,
  PHASE_BARRIER_EXPANSION,
  PHASE_ADD_UNSAFE_BARRIER,
  PHASE_END,
  PHASE_FAILURE,
  PHASE_SPLIT_INLINES_ARRAY,
  PHASE_SPLIT_INLINES_ARRAY_IGVN,
  PHASE_DEBUG,
  PHASE_NUM_TYPES
||||||| ae2504b4692
  PHASE_BEFORE_STRINGOPTS,
  PHASE_AFTER_STRINGOPTS,
  PHASE_BEFORE_REMOVEUSELESS,
  PHASE_AFTER_PARSING,
  PHASE_ITER_GVN1,
  PHASE_EXPAND_VUNBOX,
  PHASE_SCALARIZE_VBOX,
  PHASE_INLINE_VECTOR_REBOX,
  PHASE_EXPAND_VBOX,
  PHASE_ELIMINATE_VBOX_ALLOC,
  PHASE_PHASEIDEAL_BEFORE_EA,
  PHASE_ITER_GVN_AFTER_VECTOR,
  PHASE_ITER_GVN_BEFORE_EA,
  PHASE_ITER_GVN_AFTER_EA,
  PHASE_ITER_GVN_AFTER_ELIMINATION,
  PHASE_PHASEIDEALLOOP1,
  PHASE_PHASEIDEALLOOP2,
  PHASE_PHASEIDEALLOOP3,
  PHASE_CCP1,
  PHASE_ITER_GVN2,
  PHASE_PHASEIDEALLOOP_ITERATIONS,
  PHASE_OPTIMIZE_FINISHED,
  PHASE_GLOBAL_CODE_MOTION,
  PHASE_FINAL_CODE,
  PHASE_AFTER_EA,
  PHASE_BEFORE_CLOOPS,
  PHASE_AFTER_CLOOPS,
  PHASE_BEFORE_BEAUTIFY_LOOPS,
  PHASE_AFTER_BEAUTIFY_LOOPS,
  PHASE_BEFORE_MATCHING,
  PHASE_MATCHING,
  PHASE_INCREMENTAL_INLINE,
  PHASE_INCREMENTAL_INLINE_STEP,
  PHASE_INCREMENTAL_INLINE_CLEANUP,
  PHASE_INCREMENTAL_BOXING_INLINE,
  PHASE_CALL_CATCH_CLEANUP,
  PHASE_INSERT_BARRIER,
  PHASE_MACRO_EXPANSION,
  PHASE_BARRIER_EXPANSION,
  PHASE_ADD_UNSAFE_BARRIER,
  PHASE_END,
  PHASE_FAILURE,
  PHASE_DEBUG,

  PHASE_NUM_TYPES
=======
  COMPILER_PHASES(table_entry)
  PHASE_NUM_TYPES,
  PHASE_NONE
};
#undef table_entry

static const char* phase_descriptions[] = {
#define array_of_labels(name, description) description,
       COMPILER_PHASES(array_of_labels)
#undef array_of_labels
};

static const char* phase_names[] = {
#define array_of_labels(name, description) #name,
       COMPILER_PHASES(array_of_labels)
#undef array_of_labels
>>>>>>> jdk-19+15
};

class CompilerPhaseTypeHelper {
  public:
<<<<<<< HEAD
  static const char* to_string(CompilerPhaseType cpt) {
    switch (cpt) {
      case PHASE_BEFORE_STRINGOPTS:          return "Before StringOpts";
      case PHASE_AFTER_STRINGOPTS:           return "After StringOpts";
      case PHASE_BEFORE_REMOVEUSELESS:       return "Before RemoveUseless";
      case PHASE_AFTER_PARSING:              return "After Parsing";
      case PHASE_ITER_GVN1:                  return "Iter GVN 1";
      case PHASE_EXPAND_VUNBOX:              return "Expand VectorUnbox";
      case PHASE_SCALARIZE_VBOX:             return "Scalarize VectorBox";
      case PHASE_INLINE_VECTOR_REBOX:        return "Inline Vector Rebox Calls";
      case PHASE_EXPAND_VBOX:                return "Expand VectorBox";
      case PHASE_ELIMINATE_VBOX_ALLOC:       return "Eliminate VectorBoxAllocate";
      case PHASE_PHASEIDEAL_BEFORE_EA:       return "PhaseIdealLoop before EA";
      case PHASE_ITER_GVN_AFTER_VECTOR:      return "Iter GVN after vector box elimination";
      case PHASE_ITER_GVN_BEFORE_EA:         return "Iter GVN before EA";
      case PHASE_ITER_GVN_AFTER_EA:          return "Iter GVN after EA";
      case PHASE_ITER_GVN_AFTER_ELIMINATION: return "Iter GVN after eliminating allocations and locks";
      case PHASE_PHASEIDEALLOOP1:            return "PhaseIdealLoop 1";
      case PHASE_PHASEIDEALLOOP2:            return "PhaseIdealLoop 2";
      case PHASE_PHASEIDEALLOOP3:            return "PhaseIdealLoop 3";
      case PHASE_CCP1:                       return "PhaseCCP 1";
      case PHASE_ITER_GVN2:                  return "Iter GVN 2";
      case PHASE_PHASEIDEALLOOP_ITERATIONS:  return "PhaseIdealLoop iterations";
      case PHASE_OPTIMIZE_FINISHED:          return "Optimize finished";
      case PHASE_GLOBAL_CODE_MOTION:         return "Global code motion";
      case PHASE_FINAL_CODE:                 return "Final Code";
      case PHASE_AFTER_EA:                   return "After Escape Analysis";
      case PHASE_BEFORE_CLOOPS:              return "Before CountedLoop";
      case PHASE_AFTER_CLOOPS:               return "After CountedLoop";
      case PHASE_BEFORE_BEAUTIFY_LOOPS:      return "Before beautify loops";
      case PHASE_AFTER_BEAUTIFY_LOOPS:       return "After beautify loops";
      case PHASE_BEFORE_MATCHING:            return "Before matching";
      case PHASE_MATCHING:                   return "After matching";
      case PHASE_INCREMENTAL_INLINE:         return "Incremental Inline";
      case PHASE_INCREMENTAL_INLINE_STEP:    return "Incremental Inline Step";
      case PHASE_INCREMENTAL_INLINE_CLEANUP: return "Incremental Inline Cleanup";
      case PHASE_INCREMENTAL_BOXING_INLINE:  return "Incremental Boxing Inline";
      case PHASE_CALL_CATCH_CLEANUP:         return "Call catch cleanup";
      case PHASE_INSERT_BARRIER:             return "Insert barrier";
      case PHASE_MACRO_EXPANSION:            return "Macro expand";
      case PHASE_BARRIER_EXPANSION:          return "Barrier expand";
      case PHASE_ADD_UNSAFE_BARRIER:         return "Add barrier to unsafe op";
      case PHASE_END:                        return "End";
      case PHASE_FAILURE:                    return "Failure";
      case PHASE_SPLIT_INLINES_ARRAY:        return "Split inlines array";
      case PHASE_SPLIT_INLINES_ARRAY_IGVN:   return "IGVN after split inlines array";
      case PHASE_DEBUG:                      return "Debug";
      default:
        ShouldNotReachHere();
        return NULL;
||||||| ae2504b4692
  static const char* to_string(CompilerPhaseType cpt) {
    switch (cpt) {
      case PHASE_BEFORE_STRINGOPTS:          return "Before StringOpts";
      case PHASE_AFTER_STRINGOPTS:           return "After StringOpts";
      case PHASE_BEFORE_REMOVEUSELESS:       return "Before RemoveUseless";
      case PHASE_AFTER_PARSING:              return "After Parsing";
      case PHASE_ITER_GVN1:                  return "Iter GVN 1";
      case PHASE_EXPAND_VUNBOX:              return "Expand VectorUnbox";
      case PHASE_SCALARIZE_VBOX:             return "Scalarize VectorBox";
      case PHASE_INLINE_VECTOR_REBOX:        return "Inline Vector Rebox Calls";
      case PHASE_EXPAND_VBOX:                return "Expand VectorBox";
      case PHASE_ELIMINATE_VBOX_ALLOC:       return "Eliminate VectorBoxAllocate";
      case PHASE_PHASEIDEAL_BEFORE_EA:       return "PhaseIdealLoop before EA";
      case PHASE_ITER_GVN_AFTER_VECTOR:      return "Iter GVN after vector box elimination";
      case PHASE_ITER_GVN_BEFORE_EA:         return "Iter GVN before EA";
      case PHASE_ITER_GVN_AFTER_EA:          return "Iter GVN after EA";
      case PHASE_ITER_GVN_AFTER_ELIMINATION: return "Iter GVN after eliminating allocations and locks";
      case PHASE_PHASEIDEALLOOP1:            return "PhaseIdealLoop 1";
      case PHASE_PHASEIDEALLOOP2:            return "PhaseIdealLoop 2";
      case PHASE_PHASEIDEALLOOP3:            return "PhaseIdealLoop 3";
      case PHASE_CCP1:                       return "PhaseCCP 1";
      case PHASE_ITER_GVN2:                  return "Iter GVN 2";
      case PHASE_PHASEIDEALLOOP_ITERATIONS:  return "PhaseIdealLoop iterations";
      case PHASE_OPTIMIZE_FINISHED:          return "Optimize finished";
      case PHASE_GLOBAL_CODE_MOTION:         return "Global code motion";
      case PHASE_FINAL_CODE:                 return "Final Code";
      case PHASE_AFTER_EA:                   return "After Escape Analysis";
      case PHASE_BEFORE_CLOOPS:              return "Before CountedLoop";
      case PHASE_AFTER_CLOOPS:               return "After CountedLoop";
      case PHASE_BEFORE_BEAUTIFY_LOOPS:      return "Before beautify loops";
      case PHASE_AFTER_BEAUTIFY_LOOPS:       return "After beautify loops";
      case PHASE_BEFORE_MATCHING:            return "Before matching";
      case PHASE_MATCHING:                   return "After matching";
      case PHASE_INCREMENTAL_INLINE:         return "Incremental Inline";
      case PHASE_INCREMENTAL_INLINE_STEP:    return "Incremental Inline Step";
      case PHASE_INCREMENTAL_INLINE_CLEANUP: return "Incremental Inline Cleanup";
      case PHASE_INCREMENTAL_BOXING_INLINE:  return "Incremental Boxing Inline";
      case PHASE_CALL_CATCH_CLEANUP:         return "Call catch cleanup";
      case PHASE_INSERT_BARRIER:             return "Insert barrier";
      case PHASE_MACRO_EXPANSION:            return "Macro expand";
      case PHASE_BARRIER_EXPANSION:          return "Barrier expand";
      case PHASE_ADD_UNSAFE_BARRIER:         return "Add barrier to unsafe op";
      case PHASE_END:                        return "End";
      case PHASE_FAILURE:                    return "Failure";
      case PHASE_DEBUG:                      return "Debug";
      default:
        ShouldNotReachHere();
        return NULL;
=======
  static const char* to_name(CompilerPhaseType cpt) {
    return phase_names[cpt];
  }
  static const char* to_description(CompilerPhaseType cpt) {
    return phase_descriptions[cpt];
  }
  static int to_bitmask(CompilerPhaseType cpt) {
    return (1 << cpt);
  }
};

static CompilerPhaseType find_phase(const char* str) {
  for (int i = 0; i < PHASE_NUM_TYPES; i++) {
    if (strcmp(phase_names[i], str) == 0) {
      return (CompilerPhaseType)i;
    }
  }
  return PHASE_NONE;
}

class PhaseNameIter {
 private:
  char* _token;
  char* _saved_ptr;
  char* _list;

 public:
  PhaseNameIter(ccstrlist option) {
    _list = (char*) canonicalize(option);
    _saved_ptr = _list;
    _token = strtok_r(_saved_ptr, ",", &_saved_ptr);
  }

  ~PhaseNameIter() {
    FREE_C_HEAP_ARRAY(char, _list);
  }

  const char* operator*() const { return _token; }

  PhaseNameIter& operator++() {
    _token = strtok_r(NULL, ",", &_saved_ptr);
    return *this;
  }

  ccstrlist canonicalize(ccstrlist option_value) {
    char* canonicalized_list = NEW_C_HEAP_ARRAY(char, strlen(option_value) + 1, mtCompiler);
    int i = 0;
    char current;
    while ((current = option_value[i]) != '\0') {
      if (current == '\n' || current == ' ') {
        canonicalized_list[i] = ',';
      } else {
        canonicalized_list[i] = current;
      }
      i++;
>>>>>>> jdk-19+15
    }
    canonicalized_list[i] = '\0';
    return canonicalized_list;
  }
};

class PhaseNameValidator {
 private:
  bool _valid;
  char* _bad;

 public:
  PhaseNameValidator(ccstrlist option, uint64_t& mask) : _valid(true), _bad(nullptr) {
    for (PhaseNameIter iter(option); *iter != NULL && _valid; ++iter) {

      CompilerPhaseType cpt = find_phase(*iter);
      if (PHASE_NONE == cpt) {
        const size_t len = MIN2<size_t>(strlen(*iter), 63) + 1;  // cap len to a value we know is enough for all phase descriptions
        _bad = NEW_C_HEAP_ARRAY(char, len, mtCompiler);
        // strncpy always writes len characters. If the source string is shorter, the function fills the remaining bytes with NULLs.
        strncpy(_bad, *iter, len);
        _valid = false;
      } else {
        assert(cpt < 64, "out of bounds");
        mask |= CompilerPhaseTypeHelper::to_bitmask(cpt);
      }
    }
  }

  ~PhaseNameValidator() {
    if (_bad != NULL) {
      FREE_C_HEAP_ARRAY(char, _bad);
    }
  }

  bool is_valid() const {
    return _valid;
  }

  const char* what() const {
    return _bad;
  }
};

#endif // SHARE_OPTO_PHASETYPE_HPP
